FRONT:
Rubén Palomo Fontán
ruben.palomof@gmail.com
ruben.palomo@solera.com

BACK:
Luca Ferri 
luca.ferri@solera.com

https://github.com/RubenPalomo/SoleraForum
